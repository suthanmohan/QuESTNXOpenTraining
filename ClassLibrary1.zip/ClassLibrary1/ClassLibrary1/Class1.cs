﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Class1
    {
        //in case of C/C++ for NXOpen/UFUNC  ---Main is entry point for external;;;ufusr is entry for internal
        //UGII_BASE_DIR
        //UGII_ROOT_DIR (UGII folder)
        //UGII_USER_DIR used for launching Block styler GUI
        public static int x;
        public int y { get; set; }
        public static int Main()
        {
            Class2 obj = new Class2();
            int value=0;
            int value1= 10;
            //obj.GetValues(out value, ref value1);
            //GetValues();
            //Gett
            x = -1;
            //if (x)
            //{
            //}
            return 1;
        }
    }
}

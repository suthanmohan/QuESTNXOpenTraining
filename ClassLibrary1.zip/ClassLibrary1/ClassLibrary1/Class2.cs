﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    class Class2
    {
        public int GetValues(double length, out int ValueType, out double fdfdf, ref int valu2)
        {
            ValueType =2;
            valu2 = 10;
            //Class1.x;//how to call static variable/static method 
            Class1 obj = new Class1(); //object creation
            obj.y = 10; ;

            Class1 obj1 = new Class1();
            int temp = obj1.y;
            return 1;
        }
        public int GetType()
        {
            return 1;
        }
    }
}
